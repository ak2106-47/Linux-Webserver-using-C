# Linux-Webserver-in-C
A local webserver with multithreading capability and different scheduling algorithms available

## Scheduling algorithms available:
1. FIFO - First in First out
2. SFF - Smallest File First
